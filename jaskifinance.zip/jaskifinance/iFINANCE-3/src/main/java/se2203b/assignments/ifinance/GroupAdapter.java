package se2203b.assignments.ifinance;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;

import java.sql.*;

public class GroupAdapter {
    Connection connection;
    public GroupAdapter(Connection conn, Boolean reset) throws SQLException {
        connection = conn;
        if (reset) {
            Statement statement = null;
            try {
                statement = connection.createStatement();
                statement.execute("DROP TABLE IF EXISTS Groups");
                statement.execute("CREATE TABLE Groups (GroupID INT, GroupName VARCHAR(20), GroupParent INT REFERENCES Groups(GroupID), GroupElement VARCHAR(20) REFERENCES Categories(Name))");

                this.insertGroup(1,"Fixed Assets",0,"Assets");
                this.insertGroup(2,"Investments",0,"Assets");
                this.insertGroup(3,"Branch/divisions",0,"Assets");
                this.insertGroup(4,"Cash in hand",0,"Assets");
                this.insertGroup(5,"Bank accounts",0,"Assets");
                this.insertGroup(6,"Deposits (assets)",0,"Assets");
                this.insertGroup(7,"Advances (assets)",0,"Assets");
                this.insertGroup(8,"Capital account",0,"Liabilities");
                this.insertGroup(9,"Long term loans",0,"Liabilities");
                this.insertGroup(10,"Current liabilities",0,"Liabilities");
                this.insertGroup(11,"Reserves and surplus",0,"Liabilities");
                this.insertGroup(12,"Sales account",0,"Income");
                this.insertGroup(13,"Purchase account",0,"Expenses");
                this.insertGroup(14,"Expenses (direct)",0,"Expenses");
                this.insertGroup(15,"Expenses (indirect)",0,"Expenses");
                this.insertGroup(16,"Secured loans",9,"Liabilities");
                this.insertGroup(17,"Unsecured loans",9,"Liabilities");
                this.insertGroup(18,"Duties taxes payable",10,"Liabilities");
                this.insertGroup(19,"Provisions",10,"Liabilities");
                this.insertGroup(20,"Sundry creditors",10,"Liabilities");
                this.insertGroup(21,"Bank od & limits",10,"Liabilities");
            } catch (SQLException ex) {
                //
            } finally {
                if (statement != null) {
                    statement.close();
                }
            }
            connection.close();
        }
    }
    public void insertGroup(int groupID, String groupName, int groupParent, String groupElement) throws SQLException {
        Statement stmt = connection.createStatement();

        stmt.executeUpdate("INSERT INTO Groups (GroupID, GroupName, GroupParent, GroupElement) "
                + "VALUES (" + groupID + ",'" + groupName + "',"+ groupParent +",'"+ groupElement +"')");

    }
    public void modifyGroup(int groupID, String groupName) throws SQLException {
        Statement stmt = connection.createStatement();
        String str = "UPDATE Groups SET GroupName='"+groupName+"' WHERE GroupID= "+groupID;
        stmt.executeUpdate(str);
    }
    public void deleteGroup(int groupId) throws SQLException {
        Statement stmt = connection.createStatement();
        String str = "DELETE FROM Groups WHERE GroupID= "+groupId;
        stmt.executeUpdate(str);;
    }
    public TreeItem<Group> addGroup(Group group, String newName) throws SQLException {
        int parentID = group.getID();
        int newGroupID = searchForHighestID() + 1;
        AccountCategory accountCategory = group.getElement();
        if (accountCategory == null) {
            accountCategory = (AccountCategory) group;
        }
        TreeItem<Group> newGroup = new TreeItem<>(new Group(newGroupID, newName, group, accountCategory));
        if (parentID != 0) {
            // The group has a parent
            this.insertGroup(newGroupID, newName, parentID, accountCategory.getName());
        } else {
            // The group does not have a parent
            this.insertGroup(newGroupID, newName, 0, accountCategory.getName());
        }

        // Add new group to the database and update its parent ID if it has one
        String updateStatement = "UPDATE Groups SET GroupParent = ? WHERE GroupID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(updateStatement)) {
            pstmt.setInt(1, parentID);
            pstmt.setInt(2, newGroupID);
            pstmt.executeUpdate();
        }

        return newGroup;
    }
    public TreeItem<Group> changeGroup(Group group, String newName) throws SQLException {
        group.setName(newName); // Set the new name of the group

        // Update the name of the group in the groups table
        this.modifyGroup(group.getID(), newName);

        // Create a new TreeItem with the updated group
        TreeItem<Group> updatedGroup = new TreeItem<>(group);

        return updatedGroup;
    }
    public void removeGroup(Group group) throws SQLException {
        int groupID = group.getID();
        this.deleteGroup(groupID);
    }
    public ObservableList<Group> getGroupsList() throws SQLException {
        ObservableList<Group> groupList = FXCollections.observableArrayList();

        // Retrieve data from Groups table
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM Groups");

        // Loop through result set and add Group objects to list
        while (rs.next()) {
            int groupID = rs.getInt("GroupID");
            String groupName = rs.getString("GroupName");
            int groupParentID = rs.getInt("GroupParent");

            // Get AccountCategory object from Categories table
            String categoryName = rs.getString("GroupElement");
            Statement stmt2 = connection.createStatement();
            ResultSet rs2 = stmt2.executeQuery("SELECT * FROM Categories WHERE Name='" + categoryName + "'");
            if (rs2.next()) {
                String categoryType = rs2.getString("Type");
                AccountCategory category = new AccountCategory(categoryName, categoryType);

                // Get Group parent object if it exists
                Group groupParent = null;
                if (groupParentID != 0) {
                    Statement stmt3 = connection.createStatement();
                    ResultSet rs3 = stmt3.executeQuery("SELECT * FROM Groups WHERE GroupID=" + groupParentID);
                    if (rs3.next()) {
                        groupParent = new Group(rs3.getInt("GroupID"), rs3.getString("GroupName"), null, null);
                    }
                    rs3.close();
                    stmt3.close();
                }

                // Create new Group object and add to list
                Group group = new Group(groupID, groupName, groupParent, category);
                groupList.add(group);
            }
            rs2.close();
            stmt2.close();
        }
        rs.close();
        stmt.close();
        return groupList;
    }
    public int searchForHighestID() throws SQLException {//searchs for the highestID and returns it + 1
        int highest = 0;

        //searching for the highest ID
        for(int i = 1; i<getGroupsList().size(); i++){
            if(getGroupsList().get(i).getID() > getGroupsList().get(highest).getID()){
                highest = i;
            }

        }
        return getGroupsList().get(highest).getID() + 1;//returns highest ID + 1
    }
}
