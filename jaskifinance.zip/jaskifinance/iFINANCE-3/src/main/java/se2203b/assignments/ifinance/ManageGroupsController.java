package se2203b.assignments.ifinance;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class ManageGroupsController implements Initializable {

    TreeItem<Group> currentItem= new TreeItem<>(new Group());

    @FXML
    MenuItem addGroup=new MenuItem("Add New Group");

    @FXML
    MenuItem changeGroup = new MenuItem("Change Group Name");
    @FXML
    MenuItem deleteGroup = new MenuItem("Delete Group");

    @FXML
    TextField nameField;

    boolean performChange = false;

    boolean performAdd = false;



    @FXML
    Button exitBtn;
    @FXML
    TreeView<Group> treeView = new TreeView<>();
    GroupAdapter groupAdapter;

    AccountCategoryAdapter accountCategoryAdapter;

    IFinanceController iFinanceController;
    final ObservableList<AccountCategory> categories = FXCollections.observableArrayList();
    final ObservableList<Group> groups = FXCollections.observableArrayList();

    public void setAdapters(GroupAdapter groupAdapter, AccountCategoryAdapter accountCategoryAdapter) throws SQLException {
        this.groupAdapter = groupAdapter;
        this.accountCategoryAdapter = accountCategoryAdapter;

        buildData();

    }

    public void selectItem() {
        TreeItem<Group> checkNull = treeView.getSelectionModel().getSelectedItem();
        if (checkNull != null) {
            currentItem = checkNull;
            if (currentItem.isLeaf() && currentItem.getChildren().size() > 0) {
                deleteGroup.setDisable(true);
            } else {
                deleteGroup.setDisable(false);
            }
        } else {
            deleteGroup.setDisable(true);
        }

        if (selectedIsAccountCategory()) {
            changeGroup.setDisable(true);
            deleteGroup.setDisable(true);
        } else {
            changeGroup.setDisable(false);
            if (currentItem == null || !currentItem.getChildren().isEmpty()) {
                deleteGroup.setDisable(true);
            } else {
                deleteGroup.setDisable(false);
            }
        }
    }
    private boolean selectedIsAccountCategory() {//returns if the tree item selected by the user is an account type
        if(currentItem.getValue().getName().equals("Assets") ||
                currentItem.getValue().getName().equals("Liabilities") ||
                currentItem.getValue().getName().equals("Income") ||
                currentItem.getValue().getName().equals("Expenses")){
            return true;
        }
        return false;
    }
    public void save() throws SQLException {
        if (performAdd) {
            TreeItem<Group> newGroup = groupAdapter.addGroup(currentItem.getValue(), nameField.getText());
            currentItem.getChildren().add(newGroup);
        } else if (performChange) {
            TreeItem<Group> newGroup = groupAdapter.changeGroup(currentItem.getValue(), nameField.getText());
            currentItem.setValue(newGroup.getValue());
        }
        nameField.clear();
        performAdd = false;
        performChange = false;
        treeView.refresh();
    }
    public void exit(){
        Stage stage = (Stage) exitBtn.getScene().getWindow();
        stage.close();
    }


    public void setIFinanceController(IFinanceController controller) {
        iFinanceController = controller;

    }
    public void buildData() throws SQLException {
        groups.addAll(groupAdapter.getGroupsList());
        categories.addAll(accountCategoryAdapter.getCategoriesList());

        // create the root node
        TreeItem<Group> rootItem = new TreeItem<>(new Group());

        // add categories as children of root node
        for (AccountCategory category : categories) {
            TreeItem<Group> categoryItem = new TreeItem<>(new AccountCategory(category.getName(), category.getType()));
            rootItem.getChildren().add(categoryItem);

            // add groups as children of category item
            for (Group group : groups) {
                if (group.getParent() == null && group.getElement().getName().equals(categoryItem.getValue().getName())) {
                    // group has no group parent, so its parent is the category
                    TreeItem<Group> groupItem = new TreeItem<>(group);
                    categoryItem.getChildren().add(groupItem);

                    // recursively add children of group item
                    addChildrenRecursive(groupItem, group);
                }
            }
        }

        treeView.setRoot(rootItem);
        treeView.setShowRoot(false);
    }

    private void addChildrenRecursive(TreeItem<Group> parentItem, Group parentGroup) {
        for (Group group : groups) {
            if (group.getParent() != null && group.getParent().getName().equals(parentGroup.getName())) {
                // group has a group parent, so its parent is the group parent
                TreeItem<Group> groupItem = new TreeItem<>(group);
                parentItem.getChildren().add(groupItem);

                // recursively add children of group item
                addChildrenRecursive(groupItem, group);
            }
        }
    }

    private void displayAlert(String msg) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("Alert.fxml"));
            Parent ERROR = loader.load();
            AlertController controller = (AlertController) loader.getController();

            Scene scene = new Scene(ERROR);
            Stage stage = new Stage();
            stage.setScene(scene);

            stage.getIcons().add(new Image("file:src/main/resources/se2203b/assignments/ifinance/WesternLogo.png"));
            controller.setAlertText(msg);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException ex1) {

        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ContextMenu contextMenu = new ContextMenu();

        addGroup.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                performAdd=true;
                performChange=false;
                nameField.requestFocus();
            }
        });
        changeGroup.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                performAdd=false;
                performChange=true;
                nameField.requestFocus();
            }
        });
        deleteGroup.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    groupAdapter.removeGroup(currentItem.getValue());
                    currentItem.getParent().getChildren().remove(currentItem);
                    currentItem.setValue(null);
                    treeView.refresh();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        contextMenu.getItems().addAll(addGroup, changeGroup, deleteGroup);
        treeView.setContextMenu(contextMenu);

    }
}


